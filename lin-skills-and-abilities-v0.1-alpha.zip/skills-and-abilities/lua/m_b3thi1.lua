function EEex_Actionbar_Hook_HasFullThieving(sprite)
    return true
end
